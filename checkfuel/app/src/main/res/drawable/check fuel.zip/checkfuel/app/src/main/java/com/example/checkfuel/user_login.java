package com.example.checkfuel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import android.util.Log;


import java.util.Objects;

public class user_login extends AppCompatActivity {

    EditText user, password;
    TextView login, register, ForgotPassword;

    ImageView Back, Home;

    private static final String TAG = "MyActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        user = findViewById(R.id.U_Login_User);
        password = findViewById(R.id.U_Login_Password);
        login = findViewById(R.id.U_Login_Login);
        ProgressBar progressBar = findViewById(R.id.U_Login_ProgressBar);
        ForgotPassword = findViewById(R.id.U_Login_ForgotPassword);
        register = findViewById(R.id.U_Login_Register);

        Back = findViewById(R.id.U_Login_Back);
        Home = findViewById(R.id.U_Login_Home);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validateUser() | !validatePassword()){

                }else{
                    checkuser();
                }
            }
        });

        ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), UserForgotPassword.class);
                startActivity(intent);
                finish();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), UserRegistration.class);
                startActivity(intent);
                finish();
            }
        });

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public boolean validateUser(){
        String val = user.getText().toString();
        if(val.isEmpty()){
            user.setError("Username cannot be empty");
            return false;
        } else {
            user.setError(null);
            return true;
        }
    }
    public boolean validatePassword(){
        String val = password.getText().toString();
        if(val.isEmpty()){
            password.setError("Password cannot be empty");
            return false;
        } else {
            user.setError(null);
            return true;
        }
    }
    public void checkuser(){
        String username = user.getText().toString().trim();
        String userpassword = password.getText().toString().trim();  // Fixed this line

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        Query checkuserDatabase = reference.orderByChild("username").equalTo(username);

        checkuserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    user.setError(null);
                    String passwordFromDB = snapshot.child(username).child("password").getValue(String.class);

                    if(passwordFromDB.equals(userpassword)){
                        user.setError(null);

                        String nameFromDB = snapshot.child(username).child("username").getValue(String.class);
                        String emailFromDB = snapshot.child(username).child("email").getValue(String.class);
                        String contactNoFromDB = snapshot.child(username).child("contactNo").getValue(String.class);

                        Intent intent = new Intent(user_login.this, UserHome.class);
                        intent.putExtra("username", nameFromDB);
                        intent.putExtra("email", emailFromDB);
                        intent.putExtra("contactNo", contactNoFromDB);
                        intent.putExtra("password", passwordFromDB);
                        startActivity(intent);  // You forgot to start the activity here
                    } else {
                        password.setError("Invalid Password");
                        password.requestFocus();
                    }
                } else {
                    user.setError("User does not exist");
                    user.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Database Error: " + error.getMessage());
            }
        });
    }

}
