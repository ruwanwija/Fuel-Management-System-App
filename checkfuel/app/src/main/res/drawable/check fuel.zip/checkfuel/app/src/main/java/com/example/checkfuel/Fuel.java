package com.example.checkfuel;

public class Fuel {
    String station,fuel,price;

    public String getStation() {
        return station;
    }

    public String getFuel() {
        return fuel;
    }

    public String getPrice() {
        return price;
    }
}
