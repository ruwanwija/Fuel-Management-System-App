package com.example.checkfuel;

public class User {
    private String username;
    private String email;
    private String contactNo;
    private String password;

    // Constructors, setters, and other methods...

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getContactNo() {
        return contactNo;
    }

    public String getPassword() {
        return password;
    }
}

