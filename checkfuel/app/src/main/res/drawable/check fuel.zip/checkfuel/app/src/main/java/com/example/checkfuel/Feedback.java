package com.example.checkfuel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Feedback extends AppCompatActivity {

    EditText email,feedback;

    TextView submit;

    private FirebaseDatabase firebaseDatabase;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Feedback");

        email=findViewById(R.id.U_Feedback_Email);
        feedback=findViewById(R.id.U_Feedback_Feedback);
        submit=findViewById(R.id.U_Feedback_Submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getEmail = email.getText().toString();
                String getFeedback = feedback.getText().toString();

                if (TextUtils.isEmpty(getEmail) || TextUtils.isEmpty(getFeedback)) {
                    Toast.makeText(Feedback.this, "Please fill in all fields", Toast.LENGTH_LONG).show();
                    return;
                }

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("email", getEmail);
                hashMap.put("feedback", getFeedback);

                // Generate a unique key for this feedback
                String feedbackKey = databaseReference.push().getKey();

                databaseReference.child(feedbackKey).setValue(hashMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(Feedback.this, "Submitted Feedback", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Feedback.this, "Feedback Fail: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });



    }


}