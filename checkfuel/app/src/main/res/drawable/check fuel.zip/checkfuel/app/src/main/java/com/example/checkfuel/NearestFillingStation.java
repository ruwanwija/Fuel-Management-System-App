package com.example.checkfuel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;



public class NearestFillingStation extends AppCompatActivity implements OnMapReadyCallback{

    ImageView Back, Home;
    GoogleMap googleMap;

    LocationManager locationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearest_filling_station);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.User_Nearest_Filling_Station);
        mapFragment.getMapAsync(this);

        Home=findViewById(R.id.User_Nearest_Filling_Station_Home);
        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        Back=findViewById(R.id.User_Nearest_Filling_Station_Back);
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), UserHome.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private List<FillingStationInfo> getFillingStationsFromDatabase() {
        List<FillingStationInfo> fillingStations = new ArrayList<>();

        DatabaseReference fillingStationsRef = FirebaseDatabase.getInstance().getReference().child("Filling_Station");

        fillingStationsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String username = snapshot.child("username").getValue(String.class);
                    Double latitude = snapshot.child("latitude").getValue(Double.class);
                    Double longitude = snapshot.child("longitude").getValue(Double.class);

                    if (username != null && latitude != null && longitude != null) {
                        LatLng location = new LatLng(latitude, longitude);
                        googleMap.addMarker(new MarkerOptions().position(location).title(username));
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error here
            }
        });

        return fillingStations;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.googleMap = googleMap;

        // Set the initial camera position to Sri Lanka
        LatLng sriLanka = new LatLng(7.8731, 80.7718);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sriLanka, 7));

        // Retrieve and add filling stations to the map
        List<FillingStationInfo> fillingStations = getFillingStationsFromDatabase();

        if (googleMap != null) {
            for (FillingStationInfo station : fillingStations) {
                LatLng location = station.getLocation();
                String username = station.getUsername();

                googleMap.addMarker(new MarkerOptions().position(location).title(username));
            }
        }
    }
}
