package com.example.checkfuel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class FillingDetails extends AppCompatActivity {

    ListView listView;
    ArrayList<FuelDetails> fuelList;
    ArrayAdapter<FuelDetails> adapter;

    EditText name, price;

    TextView add;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filling_details);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Filling_Details");

        Intent intent = getIntent();
        String fillingStationName = intent.getStringExtra("FILLING_STATION_NAME");
        Log.d("FillingDetails", "Filling station name received: " + fillingStationName);

        listView = findViewById(R.id.FS_FD_List);
        name = findViewById(R.id.Fs_Fd_Name);
        price = findViewById(R.id.Fs_Fd_Price);
        add = findViewById(R.id.Fs_Fd_Add);

        fuelList = new ArrayList<>();

        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, fuelList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                FuelDetails fuelDetails = fuelList.get(i);
                makeToast("Name: " + fuelDetails.getName() + ", Price: " + fuelDetails.getPrice());
            }
        });

        add = findViewById(R.id.Fs_Fd_Add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fuelName = name.getText().toString();
                double fuelPrice = Double.parseDouble(price.getText().toString());

                if (fuelName.isEmpty() || fuelPrice <= 0) {
                    makeToast("Invalid input. Please enter both name and price.");
                } else {
                    FuelDetails newFuel = new FuelDetails(fuelName, fuelPrice);
                    addItem(newFuel);
                    name.setText("");
                    price.setText("");
                    makeToast("Added: " + newFuel.getName() + ", Price: " + newFuel.getPrice());
                }
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("FillingDetails", "Submit button clicked");
                String fuelName = name.getText().toString();
                double fuelPrice = Double.parseDouble(price.getText().toString());

                if (fuelName.isEmpty() || fuelPrice <= 0) {
                    makeToast("Invalid input. Please enter both name and price.");
                } else {
                    FuelDetails newFuel = new FuelDetails(fuelName, fuelPrice);

                    DatabaseReference fillingStationRef = databaseReference.child(fillingStationName);
                    DatabaseReference fuelRef = fillingStationRef.child(fuelName);

                    fuelRef.child("name").setValue(fuelName);
                    fuelRef.child("price").setValue(fuelPrice)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    makeToast("Data stored");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.e("Firebase", "Error writing document", e);
                                    makeToast("Data not stored");
                                }
                            });

                    addItem(newFuel);
                    name.setText("");
                    price.setText("");
                    makeToast("Added: " + newFuel.getName() + ", Price: " + newFuel.getPrice());
                }
            }
        });
    }

    public void addItem(FuelDetails fuel) {
        fuelList.add(fuel);
        adapter.notifyDataSetChanged();
    }

    public void makeToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
