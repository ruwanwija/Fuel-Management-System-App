package com.example.checkfuel;

import static com.google.android.material.color.utilities.MaterialDynamicColors.error;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;


public class UserProfile extends AppCompatActivity {

    TextView username, userEmail, userContactNo, userPassword;

    ImageView back,home;
    private FirebaseUser user;
    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Check if the user is authenticated
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            // If not authenticated, redirect to login screen
            Intent intent = new Intent(this, user_login.class);
            startActivity(intent);
            finish(); // Finish this activity to prevent the user from going back to the profile
        } else {
            // If authenticated, continue with profile display
            reference = FirebaseDatabase.getInstance().getReference("Users");

            // Initialize TextViews
            username = findViewById(R.id.User_Profile_Username);
            userEmail = findViewById(R.id.User_Profile_Email);
            userPassword = findViewById(R.id.User_Profile_Password);
            userContactNo = findViewById(R.id.User_Profile_Contact_No);
            back=findViewById(R.id.U_Profile_Back);
            home=findViewById(R.id.U_Profile_Home);
            // Display user data
            showUserData();



        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),UserHome.class);
                startActivity(intent);
                finish();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void showUserData() {
        // Retrieve data from Intent
        Intent intent = getIntent();
        String receivedUsername = intent.getStringExtra("username");
        String receivedEmail = intent.getStringExtra("email");
        String receivedContactNo = intent.getStringExtra("contactNo");
        String receivedPassword = intent.getStringExtra("password");

        // Set data to TextViews
        username.setText(receivedUsername);
        userEmail.setText(receivedEmail);
        userContactNo.setText(receivedContactNo);
        userPassword.setText(receivedPassword);
    }



}
